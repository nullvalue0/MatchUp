	
NASM-IDE Version 1.1
~~~~~~~~~~~~~~~~~~~~

Readme file, Rob Anderton, 28th December 1997
---------------------------------------------


Contents
--------

1. Disclaimer and license
2. What is NASM-IDE?
3. System requirements
4. Installation
5. Contacting the author
6. Bugs, limitations and the future
7. Revision history



1. Disclaimer and license
-------------------------

NASM-IDE refers to all files included in the NASM-IDE archive (e.g help files,
logo, etc). This archive must not be distributed with anything other than the 
files listed below.


 Filename	  Size (bytes)	Description

 NASMIDE  EXE     195,760  	Main NASM-IDE application
 NASM     EXE     188,961  	NASM version 0.95 executable
 NASMIDE  INI       1,035  	NASM-IDE settings file
 NASMIDE  HLP     127,590  	NASM-IDE online help file
 8087HELP HLP     101,938  	80x87 opcode reference help file
 8086HELP HLP     276,923  	80x86 opcode reference help file
 NASMIDE  RES       3,915  	NASM-IDE resource data
 NASMIDE  SPF      64,778  	NASM-IDE logo file
 NASMIDE  ICO	      766	NASM-IDE Windows icon (32x32 16 colours)	
 README   TXT       7,254    	This readme file

 ** The following files are located in the EXAMPLES directory **

 BINTEST  ASM       1,624  	Simple binary file example
 DAZZLER  ASM       6,228  	Text mode display demo
 FIRE     ASM       4,577  	VGA fire effect demo
 FIREPAL  INC       4,722  	Include file for FIRE.ASM
 BAR      ASM      13,493  	Copper bars demo
 ERRORS   ASM       1,701  	Source code file with errors

 
This software is provided "as is" and without warranties as to or any other 
warranties whether expressed or implied.

Because of the various hardware and software environments in which this
program may be used, no warranty of fitness for a particular purpose is
offered. Use it entirely at your own risk.

NASM-IDE is protected by UK and international copyright laws. You the right 
to use NASM-IDE both for non-commercial and commercial development of programs.

In no event shall the author be liable for any loss of profit or any other 
commercial damage, including but not limited to special, incidental, consequential 
or other damages.

This software may be freely copied, however no charge can be made for it (except
to cover the cost of postage or disks). NASM-IDE may not be included as part of
any compilation without permission from the author (see section 5 for details on
how to contact me).


2. What is NASM-IDE?
--------------------

NASM-IDE is a DOS based system providing a front-end to the Netwide Assembler 
(NASM). NASM-IDE has been designed to provide an interface which should be
as easy to use as possible for beginners and experts alike, especially those
who are familiar with Borland development products.


3. System requirements
----------------------

NASM-IDE requires the following minimum system specification:

- 286 or higher CPU
- Colour monitor (VGA recommended)
- 1.2 megabytes (approximately) minimum hard disk space
- 450K minimum conventional memory with 512K or more XMS or EMS
- DOS 3.3 or higher (NASM-IDE will run under Windows95)
- Mouse


4. Installation
---------------

The NASM-IDE archive is zipped using PKZIP. To use NASM-IDE, create a directory and 
unzip the entire archive to that directory (making sure you unzip with the '-d' option
to create the required directory structure). At the command prompt, change to your 
NASM-IDE directory and type NASMIDE, followed by return.


5. Contacting the author
------------------------

email : robanderton@geocities.com
www   : www.inglenook.co.uk/nasmide/index.html (NASM-IDE website) 	


6. Bugs, limitations and the future
-----------------------------------

This is version 1.1 of NASM-IDE. As far as I am aware there are no bugs in this 
release. If you should discover a problem, please do not hesitate to contact me
(see section 5).

A limitation of this version is the length of filenames. If the full drive,
directory and filename of a file to be assembled is too long, NASM will not be 
able to assemble the file and an 'Unable to open file' error message will be 
displayed in the error information window. The only solution to this problem is not
to use deeply nested directory structures. 

Features currently planned for NASM-IDE 1.2 include:

- formatted printer output
- greater configurability (e.g colours, assembler options, etc.)
- an update to the ASM Assistants
- further enhancements to the syntax highlighting editor
- keyboard macros (not to be confused with NASM macros)
- any other suggestions then send them to me!


7. Revision history
-------------------

Key: 

Symbol 	Description

+	New feature
- 	Removed feature
*	Bug fix
@	Optimisation/updated feature


Version 1.0

Programmed using Turbo Pascal 7.0 and Turbo Vision 2.0, NASM-IDE was released to the
world back in May 1997. 


Version 1.1

After large amounts of user feedback, included bug reports and suggestions for new
features, NASM-IDE 1.1 is released in December 1997, with the following additions and
changes.

@ now uses the standard NASM 0.96 (no modified version is required)

@ modified method used to call NASM

+ a recently used file list is now available via the File|Reopen command

+ a Save all command has been added

+ the clipboard uses the syntax highlighting editor

+ the use of a Primary file as the target Build and Run commands has been added

+ the OS/2 and COFF output formats are now supported

+ the NASM warnings can now be enabled/disabled

+ Include and output directories can now be specified

+ 80x43 / 80x50 screen modes are now supported

+ the startup logo can be disabled for systems which have trouble displaying it

+ a Close All command has been added

* the Error information viewer now displayed the correct error log

+ the Error information viewer allows an error to be selected so that the 
  appropriate source code file is opened and the cursor is position on the line
  containing the error

+ commands that are not available in the current context are now disabled

@ the NASM-IDE help has been completely rewritten and now incorporates the
  NASM 0.95 documentation

+ a full 80x86 opcode reference with MMX and Pentium Pro instruction is included

+ a full 80x87 floating point reference is included

- the Previous help topic command is not available in this version

@ the clock now correctly handles midnight (for all you coders who don't sleep!)

@ dialog boxes now update the status line and contain online help

+ double clicking on the cursor position indicator in an edit window displays the
  jump to line dialog

@ the syntax highlighting editor code has been cleaned up, removing 5000 lines of 
  unnecessary code and speeding it up enough to allow 80x50 mode to become 
  bearable

+ new example code has been included to show off NASM's features

@ configuration settings are now stored in a Windows style INI file

@ my brother drew me a nice new logo!


There are bound to be more changes that I've forgotten, but I think that's enough for
now!


